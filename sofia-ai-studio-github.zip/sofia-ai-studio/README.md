# Sofia AI Studio

A GitHub-ready starter MVP for a responsive AI studio built with Next.js, React, TypeScript and Puter.js.

## Included in this release

- Responsive dark dashboard for desktop and mobile
- Sofia AI chat through Puter.js
- Puter sign-in / sign-out
- Model selector and temperature setting (provider support may vary)
- Browser speech-to-text and text-to-speech
- Image generation through Puter when available
- Image understanding through Puter when available
- Text, Markdown, CSV and JSON file attachment
- Chat history saved in browser localStorage
- Project notes saved in browser localStorage
- ZIP export of saved project prompts and generated output
- PWA manifest, icon and service worker shell caching
- Agent prompt presets for Study, Coding, Research and Personal Assistant

## Requirements

- Node.js 20.9 or newer
- npm
- Internet connection for installing dependencies and using Puter AI

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Build for production

```bash
npm run build
npm run start
```

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. Sign in at https://vercel.com and import the repository.
3. Keep the framework preset as Next.js.
4. Deploy. No developer Puter API key is required for the browser-side Puter integration.
5. Open the deployed HTTPS URL and test Puter sign-in and AI calls.

## Publish to GitHub

Create a new empty repository on GitHub, extract this ZIP, then upload the contents (not the ZIP itself) into the repository. Alternatively:

```bash
git init
git add .
git commit -m "Initial Sofia AI Studio MVP"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/sofia-ai-studio.git
git push -u origin main
```

## Important limitations — read before launch

This is a functional starter MVP, not the full autonomous software factory described in the product vision.

- Puter AI requires internet, provider availability, user authorization and applicable usage allowance. "Free" does not mean unlimited.
- The model names shown in the selector are examples; availability and accepted options can change. Verify current supported model IDs in Puter documentation.
- PDF attachment is accepted but PDF text extraction is not implemented in this release.
- Browser speech recognition depends on browser support and microphone permission. Punjabi recognition availability varies by device/browser.
- Generated project output is saved as text/Markdown and exported as a ZIP. This release does not execute generated code in a secure sandbox.
- GitHub repository creation/push, Vercel publishing, Android APK compilation, server-side project database, Google Workspace OAuth, custom agent orchestration and subscription billing are not implemented yet.
- The service worker caches the app shell. AI, remote fonts and other cloud features are not offline.
- Browser localStorage is device/browser-specific and can be cleared by the user. It is not a cloud backup.
- Do not enter sensitive personal information or production secrets into prompts. Never place private API keys in frontend code.

## Useful documentation

- Puter: https://docs.puter.com/
- Next.js: https://nextjs.org/docs
- Vercel: https://vercel.com/docs
- GitHub: https://docs.github.com/
- Capacitor: https://capacitorjs.com/docs

## License

Add a license appropriate for your project before public distribution.
