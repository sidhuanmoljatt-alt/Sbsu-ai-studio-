 "use client";

import { useEffect, useMemo, useRef, useState } from "react";
import JSZip from "jszip";
import {
  Activity, ArrowDownToLine, ArrowUpRight, Bot, Check, ChevronDown, Code2,
  FileImage, FileText, FolderOpen, Globe2, Image as ImageIcon, Loader2,
  Menu, Mic, Moon, Paperclip, Plus, Search, Send, Settings2, Sparkles,
  SquarePen, Volume2, WandSparkles, X, Zap
} from "lucide-react";

declare global {
  interface Window {
    puter?: any;
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

type ChatMessage = { role: "user" | "assistant"; content: string; image?: string; createdAt: number };
type Project = { id: string; name: string; kind: string; prompt: string; output: string; updatedAt: number };

const starterPrompts = [
  { icon: "✦", title: "Build a website", prompt: "Build a modern responsive portfolio website for a creative developer." },
  { icon: "▦", title: "Create an app", prompt: "Create a complete expense tracker app with add, edit, delete, monthly filters and charts." },
  { icon: "◈", title: "Make a game", prompt: "Create a small playable 2D browser game with keyboard and touch controls." },
  { icon: "◎", title: "Create an AI agent", prompt: "Design a helpful study assistant agent that explains topics and creates quizzes." }
];

const starterCode = `// Sofia project workspace
// Ask Sofia to generate code for your app, website or game.
`;

export default function Home() {
  const [tab, setTab] = useState("Chat");
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("Connecting to Sofia");
  const [model, setModel] = useState("claude-sonnet-4");
  const [temperature, setTemperature] = useState(0.7);
  const [showSettings, setShowSettings] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [generatedImage, setGeneratedImage] = useState("");
  const [attachment, setAttachment] = useState<{ name: string; text?: string; dataUrl?: string } | null>(null);
  const [listening, setListening] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [notice, setNotice] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const savedMessages = localStorage.getItem("sofia.messages");
      const savedProjects = localStorage.getItem("sofia.projects");
      if (savedMessages) setMessages(JSON.parse(savedMessages));
      if (savedProjects) setProjects(JSON.parse(savedProjects));
      const savedTemp = localStorage.getItem("sofia.temperature");
      if (savedTemp) setTemperature(Number(savedTemp));
    } catch { /* Ignore corrupted local cache and start clean. */ }
  }, []);

  useEffect(() => {
    localStorage.setItem("sofia.messages", JSON.stringify(messages));
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => { localStorage.setItem("sofia.projects", JSON.stringify(projects)); }, [projects]);
  useEffect(() => { localStorage.setItem("sofia.temperature", String(temperature)); }, [temperature]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      if (window.puter) {
        setStatus("Puter AI ready");
        window.clearInterval(timer);
      }
    }, 500);
    const timeout = window.setTimeout(() => {
      if (!window.puter) setStatus("Waiting for Puter.js");
    }, 7000);
    return () => { window.clearInterval(timer); window.clearTimeout(timeout); };
  }, []);

  const currentProject = useMemo(() => projects.find(p => p.id === activeProject) ?? null, [projects, activeProject]);

  async function signIn() {
    if (!window.puter) return setNotice("Puter is still loading. Refresh the page and try again.");
    try {
      const result = await window.puter.auth.signIn();
      const details = await window.puter.auth.getUser();
      setUser(details || result);
      setSignedIn(true);
      setNotice("Signed in with Puter.");
    } catch (e: any) { setNotice(e?.message || "Sign-in was cancelled."); }
  }

  async function signOut() {
    try { await window.puter?.auth.signOut(); } catch {}
    setSignedIn(false); setUser(null); setNotice("Signed out.");
  }

  async function sendMessage(value?: string) {
    const text = (value ?? prompt).trim();
    if (!text || busy) return;
    const userMessage: ChatMessage = { role: "user", content: text + (attachment ? `\n\n[Attached file: ${attachment.name}]` : ""), createdAt: Date.now() };
    const next = [...messages, userMessage];
    setMessages(next); setPrompt(""); setBusy(true); setTab("Chat");
    const attachmentContext = attachment?.text ? `\n\nExtracted file content:\n${attachment.text.slice(0, 18000)}` : "";
    const imageContext = attachment?.dataUrl ? "\nThe user attached an image. Analyze it with image understanding if available." : "";
    try {
      if (!window.puter) throw new Error("Puter.js has not loaded. Check your internet connection and refresh.");
      let response: any;
      if (attachment?.dataUrl && window.puter.ai.img2txt) {
        const vision = await window.puter.ai.img2txt(attachment.dataUrl);
        response = await window.puter.ai.chat(`${text}\n\nImage analysis:\n${typeof vision === "string" ? vision : JSON.stringify(vision)}${attachmentContext}`, { model, temperature });
      } else {
        response = await window.puter.ai.chat(`${text}${attachmentContext}${imageContext}`, { model, temperature });
      }
      const content = typeof response === "string" ? response : response?.message?.content ?? response?.text ?? JSON.stringify(response);
      setMessages(prev => [...prev, { role: "assistant", content: String(content), createdAt: Date.now() }]);
    } catch (e: any) {
      setMessages(prev => [...prev, { role: "assistant", content: `I couldn't complete that request: ${e?.message || "Unknown error"}\n\nCheck your connection, Puter availability and model access, then try again.`, createdAt: Date.now() }]);
    } finally {
      setBusy(false); setAttachment(null);
    }
  }

  async function createImage() {
    const text = prompt.trim();
    if (!text || busy) return;
    setBusy(true); setGeneratedImage("");
    try {
      if (!window.puter?.ai?.txt2img) throw new Error("Puter image generation is not available yet.");
      const result = await window.puter.ai.txt2img(text);
      const src = typeof result === "string" ? result : result?.src || result?.url;
      if (src) setGeneratedImage(src);
      else setNotice("Image generation returned an unsupported result. Check the Puter response.");
    } catch (e: any) { setNotice(e?.message || "Image generation failed."); }
    finally { setBusy(false); }
  }

  async function attachFile(file: File) {
    if (file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = () => setAttachment({ name: file.name, dataUrl: String(reader.result) });
      reader.readAsDataURL(file);
      return;
    }
    if (file.type === "text/plain" || file.name.endsWith(".md") || file.name.endsWith(".csv") || file.name.endsWith(".json")) {
      const text = await file.text();
      setAttachment({ name: file.name, text });
      return;
    }
    if (file.type === "application/pdf") {
      setAttachment({ name: file.name, text: "PDF attached. Browser-side PDF text extraction is not included in this MVP. Please paste the relevant text or use an image/screenshot of the page." });
      return;
    }
    setAttachment({ name: file.name, text: "File attached. This file type is not parsed by the starter MVP. You can still describe what you want Sofia to do with it." });
  }

  function startVoice() {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return setNotice("Speech recognition is not supported in this browser. Try Chrome on Android.");
    const recognition = new Recognition();
    recognition.lang = "pa-IN";
    recognition.interimResults = false;
    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);
    recognition.onerror = () => { setListening(false); setNotice("Microphone recognition failed. Check browser permissions."); };
    recognition.onresult = (event: any) => setPrompt(prev => `${prev}${prev ? " " : ""}${event.results[0][0].transcript}`);
    recognition.start();
  }

  function speak(text: string) {
    if (!("speechSynthesis" in window)) return setNotice("Text-to-speech is not supported in this browser.");
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-IN";
    window.speechSynthesis.speak(utterance);
  }

  function saveProject() {
    const lastAssistant = [...messages].reverse().find(m => m.role === "assistant")?.content ?? starterCode;
    const title = messages.find(m => m.role === "user")?.content.slice(0, 38) || "Untitled project";
    const project: Project = { id: crypto.randomUUID(), name: title, kind: tab, prompt: messages.at(-2)?.content ?? prompt, output: lastAssistant, updatedAt: Date.now() };
    setProjects(prev => [project, ...prev]); setActiveProject(project.id); setTab("Projects"); setNotice("Project saved on this device.");
  }

  async function downloadProject(project?: Project) {
    const item = project ?? currentProject;
    if (!item) return setNotice("Save a project first, then download it.");
    const zip = new JSZip();
    zip.file("README.md", `# ${item.name}\n\nCreated with Sofia AI Studio.\n\n## Original prompt\n${item.prompt}\n\n## Generated output\n\n${item.output}\n`);
    zip.file("sofia-output.md", item.output);
    zip.file("project.json", JSON.stringify(item, null, 2));
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${item.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "sofia-project"}.zip`; a.click();
    URL.revokeObjectURL(url);
  }

  async function exportChat() {
    const body = messages.map(m => `## ${m.role === "user" ? "You" : "Sofia"}\n\n${m.content}`).join("\n\n---\n\n");
    const blob = new Blob([body || "# Sofia chat\n"], { type: "text/markdown" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "sofia-chat-history.md"; a.click(); URL.revokeObjectURL(url);
  }

  function newChat() { setMessages([]); setGeneratedImage(""); setTab("Chat"); setNotice("New chat started."); }

  const navItems = [
    { name: "Chat", icon: <Bot size={18}/> },
    { name: "Build Anything", icon: <WandSparkles size={18}/> },
    { name: "Image Studio", icon: <ImageIcon size={18}/> },
    { name: "Projects", icon: <FolderOpen size={18}/> },
    { name: "Agents", icon: <Activity size={18}/> }
  ];

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Sparkles size={21}/></div>
          <div><strong>sofia<span>.</span></strong><small>AI STUDIO</small></div>
          <button className="icon-button mobile-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <button className="new-chat" onClick={newChat}><Plus size={17}/> New chat</button>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {navItems.map(item => <button key={item.name} className={`nav-item ${tab === item.name ? "active" : ""}`} onClick={() => { setTab(item.name); setMobileNav(false); }}>
            {item.icon}<span>{item.name}</span>{item.name === "Build Anything" && <span className="nav-badge">AI</span>}
          </button>)}
        </nav>
        <div className="nav-label projects-label">RECENT PROJECTS</div>
        <div className="recent-list">
          {projects.slice(0, 5).map(p => <button key={p.id} className="recent-item" onClick={() => { setActiveProject(p.id); setTab("Projects"); }}><Code2 size={15}/><span>{p.name}</span></button>)}
          {projects.length === 0 && <p className="empty-small">Your projects will appear here.</p>}
        </div>
        <div className="sidebar-bottom">
          <div className="connection"><span className={`status-dot ${status === "Puter AI ready" ? "online" : ""}`}/><span>{status}</span></div>
          <button className="profile-row" onClick={signedIn ? signOut : signIn}>
            <div className="avatar">S</div><div className="profile-copy"><strong>{signedIn ? (user?.username || user?.name || "Puter user") : "Sign in to Puter"}</strong><small>{signedIn ? "Click to sign out" : "Cloud AI & storage"}</small></div><ArrowUpRight size={15}/>
          </button>
        </div>
      </aside>

      <section className="main-area">
        <header className="topbar">
          <div className="topbar-left"><button className="icon-button menu-trigger" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={19}/></button><span className="breadcrumb">Workspace <span>/</span> {tab}</span></div>
          <div className="top-actions">
            <span className="online-pill"><i/> {status === "Puter AI ready" ? "AI online" : "Connecting"}</span>
            <button className="icon-button" onClick={() => setShowSettings(!showSettings)} aria-label="Settings"><Settings2 size={18}/></button>
            <button className="user-chip" onClick={signedIn ? signOut : signIn}><span className="avatar tiny">{signedIn ? "U" : "S"}</span><span>{signedIn ? "Account" : "Sign in"}</span><ChevronDown size={14}/></button>
          </div>
        </header>

        {showSettings && <div className="settings-popover">
          <div className="panel-title"><div><strong>Model settings</strong><small>Adjust Sofia's response behavior</small></div><button className="icon-button" onClick={() => setShowSettings(false)}><X size={16}/></button></div>
          <label>AI model<select value={model} onChange={e => setModel(e.target.value)}><option value="claude-sonnet-4">Claude Sonnet 4</option><option value="gpt-4o">GPT-4o</option><option value="gemini-2.5-flash">Gemini 2.5 Flash</option></select></label>
          <label>Temperature <b>{temperature.toFixed(1)}</b><input type="range" min="0" max="1.5" step="0.1" value={temperature} onChange={e => setTemperature(Number(e.target.value))}/></label>
          <p className="settings-note">Model availability and supported parameters depend on Puter and the selected provider.</p>
          <button className="secondary-button full" onClick={exportChat}><ArrowDownToLine size={15}/> Export chat history</button>
        </div>}

        <div className="content">
          {tab === "Chat" && <div className="chat-view">
            {messages.length === 0 ? <div className="welcome">
              <div className="welcome-orb"><div className="orb-core"><Sparkles size={30}/></div><span className="orb-ring ring-one"/><span className="orb-ring ring-two"/></div>
              <div className="eyebrow"><span/> YOUR AI CREATIVE PARTNER</div>
              <h1>Ideas become <span>reality.</span></h1>
              <p className="welcome-sub">I'm Sofia. Ask me anything, build something extraordinary, or let's solve a problem together.</p>
              <div className="prompt-grid">{starterPrompts.map(p => <button className="prompt-card" key={p.title} onClick={() => sendMessage(p.prompt)}><span className="prompt-icon">{p.icon}</span><span><strong>{p.title}</strong><small>{p.prompt}</small></span><ArrowUpRight size={15}/></button>)}</div>
            </div> : <div className="conversation">
              {messages.map((m, i) => <div key={i} className={`message-row ${m.role}`}>
                <div className={`message-avatar ${m.role}`}>{m.role === "assistant" ? <Sparkles size={17}/> : "Y"}</div>
                <div className="message-body"><div className="message-meta">{m.role === "assistant" ? "Sofia" : "You"} <span>{new Date(m.createdAt).toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})}</span></div><div className="message-content">{m.content}</div>{m.role === "assistant" && <button className="speak-button" onClick={() => speak(m.content)}><Volume2 size={14}/> Listen</button>}</div>
              </div>)}
              {busy && <div className="thinking"><span className="thinking-dots"><i/><i/><i/></span> Sofia is thinking…</div>}
              <div ref={chatEndRef}/>
            </div>}
            <div className="composer-wrap">
              {attachment && <div className="attachment-chip"><Paperclip size={14}/>{attachment.name}<button onClick={() => setAttachment(null)}><X size={13}/></button></div>}
              <div className="composer">
                <button className="composer-tool" onClick={() => fileRef.current?.click()} title="Attach file"><Paperclip size={18}/></button>
                <input ref={fileRef} type="file" hidden accept="image/*,.pdf,.txt,.md,.csv,.json" onChange={e => e.target.files?.[0] && attachFile(e.target.files[0])}/>
                <textarea value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }} placeholder="Message Sofia… Ask, create, code or explore" rows={1}/>
                <button className={`composer-tool ${listening ? "listening" : ""}`} onClick={startVoice} title="Voice input"><Mic size={18}/></button>
                <button className="send-button" onClick={() => sendMessage()} disabled={!prompt.trim() || busy} aria-label="Send"><Send size={17}/></button>
              </div>
              <div className="composer-foot"><span><Sparkles size={12}/> Sofia can make mistakes. Verify important information.</span><span>Enter to send · Shift + Enter for new line</span></div>
            </div>
          </div>}

          {tab === "Build Anything" && <div className="build-view">
            <div className="section-heading"><div className="eyebrow"><span/> SOFIA BUILDER</div><h1>What will you <span>create?</span></h1><p>Describe your idea. Sofia can help plan it, generate code and save the result as a project.</p></div>
            <div className="build-command"><div className="command-top"><WandSparkles size={18}/><span>BUILD ANYTHING</span><span className="command-hint">AI WORKSPACE</span></div><textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Build me a beautiful task management app with user accounts, projects, reminders and a dark mode…"/><div className="command-bottom"><span><Paperclip size={15}/> Attach requirements in Chat</span><button className="primary-button" disabled={!prompt.trim() || busy} onClick={() => sendMessage(`Act as a senior full-stack developer. Plan and generate a complete project for this request. Include file structure, implementation code, setup instructions, and testing guidance. Be explicit about what can and cannot run in this browser MVP.\n\n${prompt}`)}><Sparkles size={16}/> Build with Sofia</button></div></div>
            <div className="build-types"><h3>Start with a template</h3><div className="template-grid">{starterPrompts.map((p, i) => <button key={p.title} className="template-card" onClick={() => setPrompt(p.prompt)}><span className={`template-icon tint-${i}`}>{p.icon}</span><strong>{p.title}</strong><small>{p.prompt}</small><ArrowUpRight size={15}/></button>)}</div></div>
            <div className="notice-box"><Zap size={17}/><span><strong>Build workflow:</strong> Sofia generates implementation guidance and code in chat. This starter release does not yet execute arbitrary projects in a cloud sandbox or compile APKs.</span></div>
          </div>}

          {tab === "Image Studio" && <div className="studio-view">
            <div className="section-heading"><div className="eyebrow"><span/> CREATIVE STUDIO</div><h1>Imagine it. <span>Generate it.</span></h1><p>Turn a text description into an image using an available Puter image model.</p></div>
            <div className="image-workspace"><div className="image-prompt"><label>Describe your image</label><textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="A cinematic futuristic university campus at sunset, beautiful architecture, ultra detailed…"/><button className="primary-button full" disabled={!prompt.trim() || busy} onClick={createImage}>{busy ? <Loader2 className="spin" size={16}/> : <WandSparkles size={16}/>} Generate image</button></div>
              <div className="image-result">{generatedImage ? <><img src={generatedImage} alt="Generated by Sofia"/><a className="secondary-button" href={generatedImage} download="sofia-generated-image.png"><ArrowDownToLine size={15}/> Download image</a></> : <div className="image-placeholder"><div><ImageIcon size={34}/><strong>Your canvas is waiting</strong><span>Your generated image will appear here.</span></div></div>}</div></div>
          </div>}

          {tab === "Projects" && <div className="projects-view">
            <div className="section-heading"><div className="eyebrow"><span/> YOUR WORKSPACE</div><h1>My <span>projects.</span></h1><p>Your saved project notes and generated outputs are stored in this browser.</p></div>
            {currentProject && <div className="project-detail"><div className="project-detail-head"><div><span className="file-tag">PROJECT OUTPUT</span><h2>{currentProject.name}</h2></div><button className="icon-button" onClick={() => setActiveProject(null)}><X size={17}/></button></div><pre>{currentProject.output}</pre><div className="project-actions"><button className="secondary-button" onClick={() => setPrompt(currentProject.prompt)}><SquarePen size={15}/> Edit prompt</button><button className="primary-button" onClick={() => downloadProject()}><ArrowDownToLine size={15}/> Download ZIP</button></div></div>}
            <div className="project-list">{projects.map(p => <div className="project-card" key={p.id}><div className="project-file-icon"><Code2 size={20}/></div><div className="project-card-copy"><strong>{p.name}</strong><small>{p.kind} · Updated {new Date(p.updatedAt).toLocaleDateString()}</small></div><button className="icon-button" title="Open" onClick={() => setActiveProject(p.id)}><ArrowUpRight size={17}/></button><button className="icon-button" title="Download" onClick={() => downloadProject(p)}><ArrowDownToLine size={17}/></button></div>)}{projects.length === 0 && <div className="empty-projects"><FolderOpen size={32}/><strong>No saved projects yet</strong><span>Ask Sofia to create something, then save it to your workspace.</span><button className="secondary-button" onClick={() => setTab("Build Anything")}>Start building</button></div>}</div>
          </div>}

          {tab === "Agents" && <div className="agents-view">
            <div className="section-heading"><div className="eyebrow"><span/> AGENT WORKSPACE</div><h1>Meet your <span>AI team.</span></h1><p>Choose a specialist to start a focused conversation with Sofia.</p></div>
            <div className="agent-grid">{[
              ["Study Agent","Explains concepts, creates notes and quizzes","📚","Help me study a topic. Explain it simply, then quiz me."],
              ["Coding Agent","Writes, reviews and explains code","⌘","Act as my senior coding mentor. Review my code and help debug it."],
              ["Research Agent","Researches topics and structures findings","⌕","Help me research a topic. Separate verified facts from uncertainty."],
              ["Personal Assistant","Helps plan, organize and think through tasks","✦","Act as my personal assistant. Help me organize my priorities."]
            ].map(a => <button className="agent-card" key={a[0]} onClick={() => { setPrompt(a[3]); setTab("Chat"); }}><span className="agent-emoji">{a[2]}</span><strong>{a[0]}</strong><small>{a[1]}</small><span className="agent-launch">Start conversation <ArrowUpRight size={14}/></span></button>)}</div>
            <div className="notice-box"><Activity size={17}/><span>These are prompt-based specialist presets. Multi-agent orchestration, custom tools and persistent server-side agent memory are planned for a later release.</span></div>
          </div>}
        </div>

        <footer className="footer"><span>© 2026 Sofia AI Studio</span><span><i/> Built for ideas without limits</span></footer>
        {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice("")}><X size={14}/></button></div>}
      </section>
    </main>
  );
}