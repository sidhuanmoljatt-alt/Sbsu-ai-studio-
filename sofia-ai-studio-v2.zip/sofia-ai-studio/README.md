# Sofia AI Studio 2.0

**Shaheed Bhagat Singh State University, Ferozepur**  
A responsive AI workspace for chat, image generation, voice, file analysis, prompt-to-project generation, project editing, preview, ZIP export and GitHub publishing.

> This is a working, deployable foundation. It is not represented as a fully autonomous cloud IDE or a production Android APK builder. The README lists exactly what works and what still requires external infrastructure.

## Included in this release

- Puter.js AI chat with live model discovery through `puter.ai.listModels()` and a temperature control.
- Puter authentication (sign in / sign out).
- Image generation through `puter.ai.txt2img()`.
- Image OCR/understanding and PDF OCR through `puter.ai.img2txt()` (PDF OCR uses Mistral OCR).
- Punjabi/Hindi/English speech input using browser SpeechRecognition where supported; speech output using browser SpeechSynthesis.
- Chat history and project metadata saved in this browser's localStorage.
- Build Anything prompt flow that requests complete source files in a machine-readable `<file path="...">` format.
- Project file editor, sandboxed HTML live preview, ZIP export containing generated source files.
- GitHub publishing to a new/existing initialized repository using a user-supplied GitHub token. The token is requested at publish time and is not persisted by this app.
- Install/share actions and a PWA manifest. The service worker is network-only; AI features require an internet connection.
- Capacitor Android wrapper configuration for a deployed HTTPS app.

## Run locally

Requirements: Node.js 20.9+ and npm.

```bash
npm install
npm run dev
```

Open http://localhost:3000. Internet access is required for Puter AI and authentication.

## Production build

```bash
npm run lint
npm run build
npm run start
```

## Deploy to Vercel + GitHub

1. Create a GitHub repository and upload the **contents of this folder**, not the ZIP file.
2. Import the repository into Vercel.
3. Use the default Next.js settings and deploy.
4. Open the HTTPS deployment and test Puter sign-in, model discovery, chat, image generation and export.

GitHub Pages is not the recommended host for this Next.js version because it does not run Next.js server features. Use Vercel for the app. GitHub remains the source repository and project publishing target.

## Android wrapper

The Capacitor wrapper loads the deployed HTTPS app. First deploy to Vercel, then set `CAPACITOR_SERVER_URL` to that HTTPS URL (copy `.env.example` to `.env.local` and set the value), then run:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Use Android Studio to build a signed APK/AAB. An APK is not included because it must be compiled and signed in an Android build environment with your signing credentials.

## GitHub publishing security

The Publish GitHub action asks for a Personal Access Token when clicked. Create a fine-grained token restricted to the target repository/account and grant the repository permissions needed to create/update repository contents. The token is held only in the current JavaScript function and is not saved in localStorage. Use a private repository if the generated code should not be public. Never paste a token into chat prompts.

## Data, privacy and usage

- Puter provides the AI/auth services. Each user must sign in and is subject to Puter's current model availability, usage limits, pricing and user-pays terms. “No developer API key” does not mean unlimited free inference.
- Chat and project data in this release are stored in the current browser's localStorage. They do not automatically sync across devices and can be cleared by the browser.
- Puter authentication is included. A separate multi-tenant application database, Google Workspace OAuth integrations, billing/subscriptions and a secure API-key vault are not included in this release.
- Custom provider API keys should be connected through a secure backend in a later deployment. Do not store production API keys in browser localStorage or commit them to GitHub.

## Current scope / not yet implemented

The following advanced requirements need additional services and development; they are not falsely marked as complete:

- Secure cloud sandbox/terminal for running arbitrary generated code.
- Automated test runners and autonomous multi-step debugging across arbitrary frameworks.
- Server database and cross-device project memory.
- Full GitHub OAuth app flow and automatic repository synchronization (current publisher uses a user-provided token).
- APK/AAB compilation pipeline and signing service.
- Production-ready 2D/3D game engine runtime, high-end multiplayer servers, and commercial-scale game creation.
- Google Drive, Docs, Sheets, Gmail, Calendar, Meet and other Workspace OAuth integrations.
- Subscription checkout, billing portal and live provider price catalogue.
- User-managed secure API key vault and arbitrary third-party model adapters.
- Production voice conversation streaming / realtime duplex voice.

## Official references

- Puter overview: https://docs.puter.com/
- Puter AI: https://docs.puter.com/AI/
- Puter image generation: https://docs.puter.com/AI/txt2img/
- Puter OCR: https://docs.puter.com/AI/img2txt/
- Puter authentication: https://docs.puter.com/Auth/
- Next.js: https://nextjs.org/docs
- Capacitor: https://capacitorjs.com/docs
- GitHub REST API: https://docs.github.com/en/rest

## License

Choose and add a license before public distribution.
