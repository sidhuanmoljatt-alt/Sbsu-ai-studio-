# Deploy Sofia AI Studio

## Recommended: Vercel

1. Extract the ZIP on your computer.
2. Create a GitHub repository and upload the files **inside** `sofia-ai-studio/` to its repository root.
3. Import that repository into Vercel.
4. Select Next.js and deploy with the default build command (`next build`).
5. Open the HTTPS deployment and test sign-in, chat, model list, image generation and project ZIP export.

Do not deploy this Next.js app as a ZIP file to GitHub Pages. GitHub Pages does not run the Next.js runtime. The repository is for source control; Vercel serves the app.

## Android

Set `CAPACITOR_SERVER_URL` to the deployed Vercel HTTPS URL, then run `npx cap add android`, `npx cap sync android`, and `npx cap open android`. Build and sign the APK/AAB in Android Studio.

## First-run checklist

- Open the HTTPS deployment.
- Click **Connect → Connect Puter account**.
- Open Settings and confirm the model catalogue loads.
- Send a short test chat.
- Test image generation (provider usage may be billable to the signed-in user).
- Upload an image or PDF and ask Sofia to extract its text.
- Open Build Anything and request a small HTML app.
- Open Projects, inspect the generated file, edit it, save it, preview it, and download the ZIP.
- Publish a non-sensitive test project to a new GitHub repository.
- Test the Install and Share actions on Android Chrome.
