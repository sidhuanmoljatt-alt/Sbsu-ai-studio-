import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "in.sbsu.ferozepur.sofia",
  appName: "Sofia AI Studio",
  webDir: "public",
  server: process.env.CAPACITOR_SERVER_URL
    ? { url: process.env.CAPACITOR_SERVER_URL, cleartext: false }
    : undefined,
  android: { allowMixedContent: false }
};

export default config;
