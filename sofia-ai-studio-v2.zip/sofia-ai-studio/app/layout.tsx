import type { Metadata, Viewport } from "next";
import Script from "next/script";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sofia AI Studio",
  description: "Shaheed Bhagat Singh State University, Ferozepur — create apps, websites, games and AI agents with Sofia.",
  applicationName: "Sofia AI Studio",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Sofia" }
};

export const viewport: Viewport = {
  themeColor: "#090b14",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        {children}
        <Script src="https://js.puter.com/v2/" strategy="afterInteractive" />
        <Script id="sofia-sw" strategy="afterInteractive">
          {`if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
            window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(console.error));
          }`}
        </Script>
      </body>
    </html>
  );
}